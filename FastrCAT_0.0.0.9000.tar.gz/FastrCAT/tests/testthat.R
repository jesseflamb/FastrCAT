library(testthat)
library(FastrCAT)

test_check("FastrCAT")

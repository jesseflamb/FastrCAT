#' FastrCAT: A package for the analysis of oceanographic data fromo FastCAT's.
#'
#' @docType package
#' @name FastrCAT
NULL
